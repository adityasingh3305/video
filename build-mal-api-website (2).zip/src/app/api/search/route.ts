import { NextRequest, NextResponse } from "next/server";
import { searchAnime } from "@/lib/anime";

export async function GET(request: NextRequest) {
  const query = (request.nextUrl.searchParams.get("q") || "").slice(0, 100);
  const results = await searchAnime(query);
  return NextResponse.json({ results });
}
