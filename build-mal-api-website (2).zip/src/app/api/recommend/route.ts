import { NextResponse } from "next/server";
import { getRanking } from "@/lib/anime";

type JikanRec = { entry?: { mal_id?: number; title?: string; images?: { jpg?: { image_url?: string } } }[] };

export async function GET() {
  try {
    const response = await fetch("https://api.jikan.moe/v4/recommendations/anime?limit=10", { next: { revalidate: 3600 } });
    if (response.ok) {
      const json = await response.json();
      const seen = new Set<number>();
      const results: { id: number; title: string; image: string }[] = [];
      for (const rec of (json.data as JikanRec[]) || []) {
        for (const entry of rec.entry || []) {
          if (entry.mal_id && !seen.has(entry.mal_id)) {
            seen.add(entry.mal_id);
            results.push({ id: entry.mal_id, title: entry.title || "", image: entry.images?.jpg?.image_url || "" });
          }
        }
      }
      if (results.length) return NextResponse.json({ results: results.slice(0, 12) });
    }
  } catch { /* fall through */ }
  return NextResponse.json({ results: await getRanking("airing", 12) });
}
