import { NextRequest, NextResponse } from "next/server";
import { getAnime } from "@/lib/anime";

export async function GET(request: NextRequest) {
  const id = Number(request.nextUrl.searchParams.get("id") || 0);
  if (!Number.isInteger(id) || id < 1) return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  const anime = await getAnime(id);
  if (!anime) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ id: anime.id, title: anime.title, image: anime.image, score: anime.score, season: anime.season, related: anime.related });
}
