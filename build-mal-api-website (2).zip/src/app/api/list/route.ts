import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/db";
import { watchlist } from "@/db/schema";
import { and, eq, desc } from "drizzle-orm";

export async function GET(request: NextRequest) {
  const visitorId = request.nextUrl.searchParams.get("visitorId");
  if (!visitorId || visitorId.length > 100) return NextResponse.json({ items: [] });
  try {
    const items = await getDb().select().from(watchlist).where(eq(watchlist.visitorId, visitorId)).orderBy(desc(watchlist.updatedAt));
    return NextResponse.json({ items });
  } catch { return NextResponse.json({ error: "List storage unavailable" }, { status: 503 }); }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { visitorId, animeId, status } = body;
    const title = typeof body.title === "string" ? body.title.slice(0, 300) : "";
    const image = typeof body.image === "string" ? body.image.slice(0, 500) : "";
    if (typeof visitorId !== "string" || !visitorId || visitorId.length > 100 || !Number.isInteger(animeId) || animeId < 1 || !["Watching", "Completed", "Plan to Watch", "On Hold", "Dropped"].includes(status)) {
      return NextResponse.json({ error: "Invalid list entry" }, { status: 400 });
    }
    const [item] = await getDb().insert(watchlist).values({ visitorId, animeId, status, title, image }).onConflictDoUpdate({ target: [watchlist.visitorId, watchlist.animeId], set: { status, title, image, updatedAt: new Date() } }).returning();
    return NextResponse.json({ item });
  } catch { return NextResponse.json({ error: "Could not save list entry" }, { status: 500 }); }
}

export async function DELETE(request: NextRequest) {
  try {
    const { visitorId, animeId } = await request.json();
    if (typeof visitorId !== "string" || !visitorId || visitorId.length > 100 || !Number.isInteger(animeId)) return NextResponse.json({ error: "Invalid entry" }, { status: 400 });
    await getDb().delete(watchlist).where(and(eq(watchlist.visitorId, visitorId), eq(watchlist.animeId, animeId)));
    return NextResponse.json({ ok: true });
  } catch { return NextResponse.json({ error: "Could not remove entry" }, { status: 500 }); }
}
