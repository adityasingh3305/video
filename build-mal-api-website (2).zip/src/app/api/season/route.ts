import { NextRequest, NextResponse } from "next/server";
import { getSeason } from "@/lib/anime";

export async function GET(request: NextRequest) {
  const year = Number(request.nextUrl.searchParams.get("year") || new Date().getUTCFullYear());
  const season = request.nextUrl.searchParams.get("season") || "summer";
  const maxYear = new Date().getUTCFullYear() + 1;
  if (!Number.isInteger(year) || year < 1980 || year > maxYear || !["winter", "spring", "summer", "fall"].includes(season)) return NextResponse.json({ results: [] });
  const anime = await getSeason(year, season, 60);
  return NextResponse.json({ results: anime.map(a => ({ id: a.id, title: a.title, image: a.image, genres: a.genres, score: a.score, members: a.members, startDate: a.startDate, episodes: a.episodes, mediaType: a.mediaType })) });
}
