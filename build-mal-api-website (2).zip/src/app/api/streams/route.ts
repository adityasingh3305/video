import { NextRequest, NextResponse } from "next/server";
import { getAnime, getAniZip } from "@/lib/anime";
import { getWatchLinks } from "@/lib/providers";
import type { AnimeIdentity } from "@/lib/providers/core";

export async function GET(request: NextRequest) {
  const malId = Number(request.nextUrl.searchParams.get("malId") || 0);
  const episode = Math.max(1, Math.min(Number(request.nextUrl.searchParams.get("episode") || 1) || 1, 2000));
  if (!Number.isInteger(malId) || malId < 1) return NextResponse.json({ error: "Invalid anime" }, { status: 400 });
  const [anime, zip] = await Promise.all([getAnime(malId), getAniZip(malId)]);
  if (!anime) return NextResponse.json({ error: "Anime not found" }, { status: 404 });
  const identity: AnimeIdentity = {
    malId,
    anilistId: zip?.anilistId || null,
    anidbId: zip?.anidbId || null,
    tvdbId: zip?.tvdbId || null,
    tmdbId: zip?.tmdbId || null,
    titles: [anime.title, ...anime.altTitles, zip?.titles.en, zip?.titles.ja, zip?.titles.romaji].filter((t): t is string => Boolean(t)),
    year: anime.startDate ? Number(anime.startDate.slice(0, 4)) || null : null,
    type: anime.mediaType,
  };
  const links = await getWatchLinks(identity, episode);
  return NextResponse.json({ episode, links });
}
