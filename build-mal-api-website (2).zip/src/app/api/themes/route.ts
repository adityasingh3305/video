import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  const id = Number(request.nextUrl.searchParams.get("id") || 0);
  if (!Number.isInteger(id) || id < 1) return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  try {
    const response = await fetch(`https://api.jikan.moe/v4/anime/${id}/themes`, { next: { revalidate: 3600 } });
    if (!response.ok) return NextResponse.json({ openings: [], endings: [] });
    const json = await response.json();
    return NextResponse.json({ openings: json?.data?.openings || [], endings: json?.data?.endings || [] });
  } catch { return NextResponse.json({ openings: [], endings: [] }); }
}
