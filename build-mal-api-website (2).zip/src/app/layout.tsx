import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Kuroiru — Explore Anime",
  description: "Explore anime, discover seasonal releases, and keep your watchlist. Anime data powered by MyAnimeList; episode metadata by AniZip.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
