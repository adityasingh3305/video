import { getCatalog } from "@/lib/anime";
import { HomeDashboard } from "@/components/home-dashboard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const catalog = await getCatalog();
  const { now } = catalog;
  return <HomeDashboard featured={catalog.featured} upcoming={catalog.upcoming.slice(0, 40)} recent={catalog.recent.slice(0, 40)} weekly={catalog.trending} daily={catalog.dailyTop} seasonLabel={`${now.season[0].toUpperCase()}${now.season.slice(1)} ${now.year}`} />;
}
