import Link from "next/link";

export const metadata = { title: "About — Kuroiru" };

export default function AboutPage() {
  return <div className="site-shell">
    <header className="topbar"><Link href="/" className="brand" aria-label="Kuroiru home">Kuroiru</Link><div className="header-actions" /></header>
    <main className="static-page">
      <h1>About Kuroiru</h1>
      <p>Kuroiru is an anime discovery dashboard. Catalog data (scores, synopses, seasons, rankings) comes from the MyAnimeList API, mirrored through Jikan and AniList when MAL is rate-limited. Episode metadata and cross-database IDs come from AniZip.</p>
      <p>Watch buttons are redirect links resolved per provider at request time — Kuroiru does not host or stream any video.</p>
      <p>Your watchlist and history are stored for your browser session only.</p>
      <p className="static-links"><Link href="/">Home</Link><Link href="/explore">Explore</Link><Link href="/terms">Terms</Link></p>
    </main>
    <footer className="site-footer"><div><span>Kuroiru.co</span><div><a href="/about">About</a><a href="/explore">Explore</a><a href="/terms">Terms</a></div></div></footer>
  </div>;
}
