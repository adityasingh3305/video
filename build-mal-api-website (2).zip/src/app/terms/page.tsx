import Link from "next/link";

export const metadata = { title: "Terms — Kuroiru" };

export default function TermsPage() {
  return <div className="site-shell">
    <header className="topbar"><Link href="/" className="brand" aria-label="Kuroiru home">Kuroiru</Link><div className="header-actions" /></header>
    <main className="static-page">
      <h1>Terms of Use</h1>
      <p>All anime metadata remains the property of its respective sources: MyAnimeList, AniList and AniZip. Kuroiru only displays links to third-party websites and is not affiliated with them.</p>
      <p>External watch links open third-party services; their availability and legality in your region are your responsibility.</p>
      <p>The service is provided as-is, without warranties of any kind.</p>
      <p className="static-links"><Link href="/">Home</Link><Link href="/about">About</Link></p>
    </main>
    <footer className="site-footer"><div><span>Kuroiru.co</span><div><a href="/about">About</a><a href="/explore">Explore</a><a href="/terms">Terms</a></div></div></footer>
  </div>;
}
