import { getCatalog } from "@/lib/anime";
import { FilterList } from "@/components/filter-list";

export const dynamic = "force-dynamic";
export const metadata = { title: "Recently Released Anime — Kuroiru" };

export default async function RecentPage() {
  const catalog = await getCatalog();
  return <FilterList heading="Recently Released" items={catalog.recent} mode="recent" />;
}
