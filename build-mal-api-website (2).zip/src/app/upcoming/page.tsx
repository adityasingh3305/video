import { getCatalog } from "@/lib/anime";
import { FilterList } from "@/components/filter-list";

export const dynamic = "force-dynamic";
export const metadata = { title: "Upcoming Anime — Kuroiru" };

export default async function UpcomingPage() {
  const catalog = await getCatalog();
  return <FilterList heading="Upcoming" items={catalog.upcoming} mode="upcoming" />;
}
