import { getAnime, getAniZip } from "@/lib/anime";
import { AnimeDetail } from "@/components/anime-detail";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function AnimePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const malId = Number(id);
  if (!Number.isInteger(malId) || malId < 1) notFound();
  const [anime, mapping] = await Promise.all([getAnime(malId), getAniZip(malId)]);
  if (!anime) notFound();
  return <AnimeDetail anime={anime} mapping={mapping} />;
}
