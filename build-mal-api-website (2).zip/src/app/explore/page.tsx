import { ExplorePage } from "@/components/explore-page";

export const dynamic = "force-dynamic";

export default function ExploreRoute() {
  return <ExplorePage />;
}
