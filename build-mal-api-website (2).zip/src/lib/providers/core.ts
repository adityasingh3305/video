export type AnimeIdentity = {
  malId: number;
  anilistId: number | null;
  anidbId: number | null;
  tvdbId: number | null;
  tmdbId: string | null;
  titles: string[];
  year: number | null;
  type: string;
};

export type ProviderAnime = { externalId: string; title?: string };

export type ResolvedLink = { provider: string; name: string; color: string; epSupported: boolean; url: string | null };

export interface WatchLinkProvider {
  id: string;
  name: string;
  color: string;
  epSupported: boolean;
  resolveAnime(identity: AnimeIdentity): Promise<ProviderAnime | null>;
  buildUrl(anime: ProviderAnime, episode: number): string;
}

export function normalizeTitle(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

function bigrams(value: string): Set<string> {
  const out = new Set<string>();
  for (let i = 0; i < value.length - 1; i++) out.add(value.slice(i, i + 2));
  return out;
}

export function diceSimilarity(a: string, b: string): number {
  if (!a || !b) return 0;
  if (a === b) return 1;
  const left = bigrams(a); const right = bigrams(b);
  let shared = 0;
  left.forEach(g => { if (right.has(g)) shared++; });
  return (2 * shared) / (left.size + right.size);
}

// Season/part/movie markers prevent "Foo" from matching "Foo 2nd Season" or movies.
function markers(value: string): string {
  const out: string[] = [];
  const season = /season\s*(\d+)/.exec(value) || /(\d+)\s*(?:st|nd|rd|th)\s*season/.exec(value);
  if (season) out.push(`s${season[1]}`);
  const part = /part\s*(\d+)/.exec(value);
  if (part) out.push(`p${part[1]}`);
  if (/\bmovie\b|\bgekijouban\b|\bmanga\b/.test(value)) out.push("movie");
  return out.sort().join(",");
}

export function scoreCandidate(candidate: string, identity: AnimeIdentity): number {
  const normalizedCandidate = normalizeTitle(candidate);
  if (!normalizedCandidate) return 0;
  const candidateMarkers = markers(normalizedCandidate);
  let best = 0;
  for (const raw of identity.titles) {
    const normalizedTitle = normalizeTitle(raw);
    if (!normalizedTitle) continue;
    let score = 0;
    if (normalizedTitle === normalizedCandidate) score = 1;
    else if (normalizedTitle.includes(normalizedCandidate) || normalizedCandidate.includes(normalizedTitle)) score = 0.85;
    else score = diceSimilarity(normalizedTitle, normalizedCandidate);
    const titleMarkers = markers(normalizedTitle);
    if (candidateMarkers !== titleMarkers && (candidateMarkers || titleMarkers)) score = Math.min(score, 0.3);
    if (score >= 1) return 1;
    best = Math.max(best, score);
  }
  return best;
}

export function pickBestMatch<Item>(items: Item[], identity: AnimeIdentity, getName: (item: Item) => string | undefined, getYear?: (item: Item) => number | null, threshold = 0.7): Item | null {
  let bestItem: Item | null = null;
  let bestScore = 0;
  for (const item of items) {
    const name = getName(item);
    if (!name) continue;
    let score = scoreCandidate(name, identity);
    if (getYear && identity.year) {
      const year = getYear(item);
      if (year && Math.abs(year - identity.year) <= 1) score += 0.1;
    }
    if (score > bestScore) { bestScore = score; bestItem = item; }
  }
  return bestScore >= threshold ? bestItem : null;
}

export async function fetchJson(url: string, options?: RequestInit): Promise<unknown | null> {
  try {
    const response = await fetch(url, { ...options, signal: AbortSignal.timeout(6000), headers: { "User-Agent": "kuroiru-resolver/1.0", ...(options?.headers || {}) } });
    if (!response.ok) return null;
    return await response.json();
  } catch { return null; }
}

export async function fetchText(url: string): Promise<string | null> {
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(7000), headers: { "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36", "Accept-Language": "en-US,en;q=0.9" } });
    return response.ok ? await response.text() : null;
  } catch { return null; }
}

// Search cascade: main title, english/alternate titles, japanese, synonyms, shortened forms.
export function cascadeQueries(identity: AnimeIdentity): string[] {
  const out: string[] = [];
  const push = (value: string | undefined) => { const v = (value || "").trim(); if (v && !out.includes(v)) out.push(v); };
  identity.titles.forEach(push);
  push(identity.titles[0]?.split(":")[0]);
  push(identity.titles[1]?.split(":")[0]);
  return out.slice(0, 6);
}
