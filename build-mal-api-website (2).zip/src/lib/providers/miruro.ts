import type { WatchLinkProvider } from "./core";

// Miruro's catalogue layer is keyed by AniList ID, which AniZip provides.
export const miruroProvider: WatchLinkProvider = {
  id: "miruro",
  name: "Miruro",
  color: "#ee791f",
  epSupported: true,
  async resolveAnime(identity) {
    return identity.anilistId ? { externalId: String(identity.anilistId) } : null;
  },
  buildUrl(anime, episode) {
    return `https://www.miruro.to/watch?id=${anime.externalId}&ep=${episode}`;
  },
};
