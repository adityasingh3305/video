import { cascadeQueries, scoreCandidate, type AnimeIdentity, type WatchLinkProvider } from "./core";

// MKissa's anime ids come from the AllAnime data layer that powers the site
// (api.mkissa.net is Cloudflare-gated; the public AllAnime GraphQL endpoint
// returns the same _id values, e.g. Clevatess S2 = 3pCcrhBgTN5vFcCsh).
const ALLANIME_API = () => process.env.ALLANIME_API || "https://api.allanime.day/api";

const QUERY = `query($search: SearchInput, $limit: Int, $page: Int, $translationType: VaildTranslationTypeEnumType, $countryOrigin: VaildCountryOriginEnumType){ shows(search: $search, limit: $limit, page: $page, translationType: $translationType, countryOrigin: $countryOrigin){ edges { _id name altNames } } }`;

type Edge = { _id?: string; name?: string; altNames?: (string | null)[] };

async function searchAllAnime(query: string): Promise<Edge[]> {
  try {
    const response = await fetch(ALLANIME_API(), {
      method: "POST",
      signal: AbortSignal.timeout(6000),
      headers: { "Content-Type": "application/json", "User-Agent": "Mozilla/5.0" },
      body: JSON.stringify({ query: QUERY, variables: { search: { query }, limit: 6, page: 1, translationType: "sub", countryOrigin: "ALL" } }),
    });
    if (!response.ok) return [];
    const json = await response.json();
    return (json?.data?.shows?.edges as Edge[]) || [];
  } catch { return []; }
}

export const mkissaProvider: WatchLinkProvider = {
  id: "mkissa",
  name: "MKissa",
  color: "#8d6e63",
  epSupported: true,
  async resolveAnime(identity: AnimeIdentity) {
    for (const query of cascadeQueries(identity)) {
      const edges = await searchAllAnime(query);
      if (!edges.length) continue;
      let best: Edge | null = null;
      let bestScore = 0;
      for (const edge of edges) {
        const score = Math.max(scoreCandidate(edge.name || "", identity), ...(edge.altNames || []).filter((n): n is string => Boolean(n)).map(n => scoreCandidate(n, identity)));
        if (score > bestScore) { bestScore = score; best = edge; }
      }
      if (best?._id && bestScore >= 0.7) return { externalId: best._id, title: best.name };
    }
    return null;
  },
  buildUrl(anime, episode) {
    return `https://mkissa.to/anime/${anime.externalId}/p-${episode}-sub`;
  },
};
