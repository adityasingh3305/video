import { cascadeQueries, fetchJson, fetchText, pickBestMatch, type WatchLinkProvider } from "./core";

// AniKoto slug discovery on demand — nothing stored.
// Strategy 1: self-hosted anikoto-api JSON (ANIKOTO_API_URL) if configured.
// Strategy 2: the live site's SSR search page, scraping watch/{slug} links with their titles.
type SearchResult = { slug?: string; title?: string };

async function scrapeResults(query: string): Promise<SearchResult[]> {
  const html = await fetchText(`https://anikototv.to/search?keyword=${encodeURIComponent(query)}`);
  if (!html) return [];
  const pairs: SearchResult[] = [...html.matchAll(/\/watch\/([a-z0-9-]+)\/ep-\d+"[^>]*>\s*<img[^>]*alt="([^"]+)"/g)]
    .map(m => ({ slug: m[1], title: m[2] }));
  if (pairs.length) return pairs;
  return [...new Set([...html.matchAll(/\/watch\/([a-z0-9-]+)\//g)].map(m => m[1]))].map(slug => ({ slug, title: slug.replace(/-/g, " ") }));
}

export const anikotoProvider: WatchLinkProvider = {
  id: "anikoto",
  name: "AniKoto",
  color: "#2f7fd1",
  epSupported: true,
  async resolveAnime(identity) {
    const base = process.env.ANIKOTO_API_URL;
    if (base) {
      const data = await fetchJson(`${base.replace(/\/$/, "")}/api/search?q=${encodeURIComponent(identity.titles[0] || "")}`);
      const results = (data as { data?: { results?: SearchResult[] } })?.data?.results || [];
      const jsonMatch = pickBestMatch(results, identity, item => item.title);
      if (jsonMatch?.slug) return { externalId: jsonMatch.slug, title: jsonMatch.title };
    }
    for (const query of cascadeQueries(identity)) {
      const results = await scrapeResults(query);
      if (!results.length) continue;
      const match = pickBestMatch(results, identity, item => item.title || item.slug?.replace(/-/g, " "));
      if (match?.slug) return { externalId: match.slug, title: match.title };
    }
    return null;
  },
  buildUrl(anime, episode) {
    return `https://anikototv.to/watch/${anime.externalId}/ep-${episode}`;
  },
};
