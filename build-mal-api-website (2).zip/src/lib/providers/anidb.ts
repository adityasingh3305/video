import type { WatchLinkProvider } from "./core";

// AniDB is referenced through the AniDB id in the AniZip mapping record.
export const anidbProvider: WatchLinkProvider = {
  id: "anidb",
  name: "AniDB",
  color: "#f07f23",
  epSupported: false,
  async resolveAnime(identity) {
    return identity.anidbId ? { externalId: String(identity.anidbId) } : null;
  },
  buildUrl(anime) {
    return `https://anidb.net/anime/${anime.externalId}`;
  },
};
