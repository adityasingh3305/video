import type { WatchLinkProvider } from "./core";

// Verified live: Kuroiru's anime ids ARE the MAL ids (search "Naruto" -> 20,
// kuroiru.co/anime/20 -> 200, /redirect/pahe/20 -> 302 to animepahe). No search
// round-trip is needed, which also removes mismatch risk.
function makeProvider(id: string, name: string, color: string, build: (externalId: string) => string, epSupported: boolean): WatchLinkProvider {
  return {
    id, name, color, epSupported,
    async resolveAnime(identity) { return { externalId: String(identity.malId) }; },
    buildUrl: (anime) => build(anime.externalId),
  };
}

const site = () => process.env.KUROIRU_SITE || "https://kuroiru.co";

export const kuroiruProvider = makeProvider("kuroiru", "Kuroiru", "#7a5cd6", id => `${site()}/anime/${id}`, false);
export const animepaheProvider = makeProvider("animepahe", "animepahe", "#b03a3a", id => `${site()}/redirect/pahe/${id}`, false);
