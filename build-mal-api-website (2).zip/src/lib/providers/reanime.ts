import { cascadeQueries, fetchJson, fetchText, pickBestMatch, type WatchLinkProvider } from "./core";

// Re:Anime slug discovery on demand — nothing stored.
// Strategy 1: self-hosted reanime-scraper JSON API (REANIME_API_URL) if configured.
// Strategy 2: the live site's SSR search page, scraping /anime/{slug} links.
type SearchResult = { slug?: string; title?: string; year?: number };

const BLOCKED = new Set(["cover", "home", "anime-list"]);

async function scrapeSlugs(query: string): Promise<string[]> {
  const html = await fetchText(`https://reanime.to/search?q=${encodeURIComponent(query)}`);
  if (!html) return [];
  const slugs = [...html.matchAll(/\/anime\/([a-z0-9-]{4,})"/g)].map(m => m[1]);
  return [...new Set(slugs)].filter(slug => !BLOCKED.has(slug));
}

export const reanimeProvider: WatchLinkProvider = {
  id: "reanime",
  name: "Re:Anime",
  color: "#58a65c",
  epSupported: true,
  async resolveAnime(identity) {
    const base = process.env.REANIME_API_URL;
    if (base) {
      const data = await fetchJson(`${base.replace(/\/$/, "")}/search?q=${encodeURIComponent(identity.titles[0] || "")}&limit=20`);
      const parsed = data as { results?: SearchResult[] } | SearchResult[] | null;
      const results: SearchResult[] = Array.isArray(parsed) ? parsed : parsed?.results || [];
      const jsonMatch = pickBestMatch(results, identity, item => item.title, item => item.year || null);
      if (jsonMatch?.slug) return { externalId: jsonMatch.slug, title: jsonMatch.title };
    }
    for (const query of cascadeQueries(identity)) {
      const slugs = await scrapeSlugs(query);
      if (!slugs.length) continue;
      const match = pickBestMatch(slugs, identity, slug => slug.replace(/-/g, " "));
      if (match) return { externalId: match };
    }
    return null;
  },
  buildUrl(anime, episode) {
    return `https://reanime.to/watch/${anime.externalId}?ep=${episode}`;
  },
};
