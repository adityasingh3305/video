import { fetchText, scoreCandidate, type WatchLinkProvider } from "./core";

// AniSnatch is keyed by MAL id, verified on demand: the watch page
// server-renders "<title>{Anime Title} - AniSnatch</title>", so the resolver
// confirms the mapping by matching that title against the identity instead of
// assuming the id scheme.
export const anisnatchProvider: WatchLinkProvider = {
  id: "anisnatch",
  name: "AniSnatch",
  color: "#f06292",
  epSupported: true,
  async resolveAnime(identity) {
    const html = await fetchText(`https://anisnatch.top/watch/${identity.malId}?ep=1`);
    if (!html) return null;
    const titleMatch = /<title>([^<]*)<\/title>/i.exec(html);
    const pageTitle = (titleMatch?.[1] || "").replace(/\s*-\s*AniSnatch\s*$/i, "").trim();
    if (!pageTitle || /^anisnatch\b/i.test(pageTitle)) return null;
    return scoreCandidate(pageTitle, identity) >= 0.6 ? { externalId: String(identity.malId), title: pageTitle } : null;
  },
  buildUrl(anime, episode) {
    return `https://anisnatch.top/watch/${anime.externalId}?ep=${episode}`;
  },
};
