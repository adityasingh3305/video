import type { AnimeIdentity, ResolvedLink, WatchLinkProvider } from "./core";
import { miruroProvider } from "./miruro";
import { anidbProvider } from "./anidb";
import { kuroiruProvider, animepaheProvider } from "./kuroiru";
import { reanimeProvider } from "./reanime";
import { anikotoProvider } from "./anikoto";
import { anisnatchProvider } from "./anisnatch";
import { mkissaProvider } from "./mkissa";

export const providers: WatchLinkProvider[] = [miruroProvider, reanimeProvider, anikotoProvider, anisnatchProvider, mkissaProvider, anidbProvider, animepaheProvider, kuroiruProvider];

// Slugs are discovered on demand and kept in memory only (per server instance).
// The slug is resolved once per anime, then episode URLs are generated from it.
const memoryCache = new Map<string, { id: string | null; at: number }>();
const inflight = new Map<string, Promise<string | null>>();
const MINUTE = 60_000;
const RESOLVE_DEADLINE = 8000;

function withDeadline<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  return Promise.race([promise, new Promise<T>(resolve => setTimeout(() => resolve(fallback), ms))]);
}

async function resolveAndCache(provider: WatchLinkProvider, identity: AnimeIdentity): Promise<string | null> {
  let id: string | null = null;
  try { id = (await provider.resolveAnime(identity))?.externalId || null; } catch { id = null; }
  memoryCache.set(`${provider.id}:${identity.malId}`, { id, at: Date.now() });
  return id;
}

async function cachedResolve(provider: WatchLinkProvider, identity: AnimeIdentity): Promise<string | null> {
  const key = `${provider.id}:${identity.malId}`;
  const now = Date.now();
  const hit = memoryCache.get(key);
  if (hit && now - hit.at < (hit.id ? 15 * MINUTE : 2 * MINUTE)) return hit.id;
  const pending = inflight.get(key) ?? withDeadline(resolveAndCache(provider, identity), RESOLVE_DEADLINE, null).finally(() => inflight.delete(key));
  inflight.set(key, pending);
  return pending;
}

export async function getWatchLinks(identity: AnimeIdentity, episode: number): Promise<ResolvedLink[]> {
  return withDeadline(Promise.all(providers.map(async provider => {
    const externalId = await cachedResolve(provider, identity);
    const url = externalId ? provider.buildUrl({ externalId }, episode) : null;
    return { provider: provider.id, name: provider.name, color: provider.color, epSupported: provider.epSupported, url } as ResolvedLink;
  })), 9000, providers.map(provider => ({ provider: provider.id, name: provider.name, color: provider.color, epSupported: provider.epSupported, url: null } as ResolvedLink)));
}
