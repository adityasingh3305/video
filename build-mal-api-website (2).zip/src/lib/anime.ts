export type Anime = {
  id: number;
  title: string;
  image: string;
  score: number | null;
  members: number;
  synopsis: string;
  genres: string[];
  status: string;
  episodes: number;
  startDate: string;
  endDate: string;
  season: string;
  mediaType: string;
  rating: string;
  source: string;
  studios: string[];
  duration: number;
  trailer: string;
  alternativeTitle: string;
  altTitles: string[];
  related: { id: number; title: string; image: string; relation: string }[];
};

type MalNode = {
  id: number; title: string; main_picture?: { medium?: string; large?: string };
  mean?: number; num_list_users?: number; synopsis?: string;
  genres?: { id: number; name: string }[]; status?: string; num_episodes?: number;
  start_date?: string; end_date?: string; start_season?: { year: number; season: string };
  media_type?: string; rating?: string; source?: string; studios?: { id: number; name: string }[];
  average_episode_duration?: number; videos?: { promo?: { youtube_id?: string }[] };
  alternative_titles?: { en?: string; ja?: string; synonyms?: string[] };
  related_anime?: { node: MalNode; relation_type_formatted?: string }[];
};

const fields = "alternative_titles,start_date,end_date,synopsis,mean,num_list_users,genres,status,num_episodes,start_season,media_type,rating,source,studios,average_episode_duration,related_anime,videos";
const listFields = "mean,num_list_users,synopsis,genres,status,num_episodes,start_date,start_season,media_type,alternative_titles";

function normalize(node: MalNode): Anime {
  return {
    id: node.id, title: node.title, image: node.main_picture?.large || node.main_picture?.medium || "",
    score: node.mean ?? null, members: node.num_list_users || 0, synopsis: node.synopsis || "",
    genres: node.genres?.map(g => g.name) || [], status: node.status || "", episodes: node.num_episodes || 0,
    startDate: node.start_date || "", endDate: node.end_date || "",
    season: node.start_season ? `${node.start_season.season} ${node.start_season.year}` : "",
    mediaType: node.media_type || "", rating: node.rating || "", source: node.source || "",
    studios: node.studios?.map(s => s.name) || [], duration: node.average_episode_duration || 0,
    trailer: node.videos?.promo?.[0]?.youtube_id || "", alternativeTitle: node.alternative_titles?.en || node.alternative_titles?.ja || "",
    altTitles: [...(node.alternative_titles?.synonyms || []), node.alternative_titles?.en || "", node.alternative_titles?.ja || ""].filter(Boolean),
    related: node.related_anime?.map(r => ({ id: r.node.id, title: r.node.title, image: r.node.main_picture?.medium || "", relation: r.relation_type_formatted || "Related" })) || [],
  };
}

async function malFetch(path: string) {
  if (!process.env.MAL_CLIENT_ID) return null;
  try {
    const response = await fetch(`https://api.myanimelist.net/v2${path}`, { headers: { "X-MAL-CLIENT-ID": process.env.MAL_CLIENT_ID }, next: { revalidate: 900 } });
    if (!response.ok) return null;
    return await response.json();
  } catch { return null; }
}

// Jikan mirrors MAL data and keeps the app alive when MAL's WAF/rate limits hit.
// Jikan rate-limits aggressively (429), so back off and retry once, and cache longer.
async function jikanFetch(path: string) {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const response = await fetch(`https://api.jikan.moe/v4${path}`, { next: { revalidate: 3600 } });
      if (response.status === 429 || response.status === 503 || response.status === 504) { await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1))); continue; }
      if (!response.ok) return null;
      return await response.json();
    } catch { return null; }
  }
  return null;
}

type JikanEntry = { mal_id?: number; type?: string; name?: string; url?: string; images?: { jpg?: { image_url?: string } } };
type JikanItem = {
  mal_id: number; title: string; images?: { jpg?: { large_image_url?: string; image_url?: string } };
  score?: number; members?: number; synopsis?: string | null;
  genres?: { name: string }[]; themes?: { name: string }[]; status?: string; episodes?: number | null;
  aired?: { from?: string; to?: string }; season?: string; year?: number; type?: string;
  rating?: string | null; source?: string; studios?: { name: string }[]; duration?: string;
  trailer?: { youtube_id?: string }; titles?: { type: string; title: string }[];
  relations?: { relation: string; entry: JikanEntry[] }[];
};

function jikanNormalize(item: JikanItem): Anime {
  const status = item.status === "Currently Airing" ? "currently_airing" : item.status === "Not yet aired" ? "not_yet_aired" : "finished_airing";
  return {
    id: item.mal_id, title: item.title, image: item.images?.jpg?.large_image_url || item.images?.jpg?.image_url || "",
    score: item.score ?? null, members: item.members || 0, synopsis: item.synopsis || "",
    genres: [...(item.genres || []), ...(item.themes || [])].map(g => g.name), status,
    episodes: item.episodes || 0, startDate: item.aired?.from ? item.aired.from.slice(0, 10) : "", endDate: item.aired?.to ? item.aired.to.slice(0, 10) : "",
    season: item.season && item.year ? `${item.season} ${item.year}` : "", mediaType: item.type || "",
    rating: item.rating || "", source: item.source || "", studios: (item.studios || []).map(s => s.name),
    duration: (Number(/(\d+)\s*hr/.exec(item.duration || "")?.[1] || 0) * 3600) + (Number(/(\d+)\s*min/.exec(item.duration || "")?.[1] || 0) * 60), trailer: item.trailer?.youtube_id || "",
    alternativeTitle: item.titles?.find(t => t.type === "English")?.title || item.titles?.find(t => t.type === "Default")?.title || "",
    altTitles: (item.titles || []).filter(t => t.type !== "Default").map(t => t.title),
    related: (item.relations || []).flatMap(r => r.entry.filter(e => e.type === "anime" && e.mal_id).map(e => ({ id: e.mal_id as number, title: e.name || "", image: e.images?.jpg?.image_url || "", relation: r.relation }))).slice(0, 8),
  };
}

const ANILIST_DETAIL = `query ($malId: Int) { Media(idMal: $malId, type: ANIME) { idMal title { userPreferred romaji english } synonyms coverImage { large } averageScore popularity episodes format status duration source startDate { year month day } endDate { year month day } season description genres studios { nodes { name } } trailer { id site } relations { edges { relationType node { idMal type title { userPreferred } coverImage { large } } } } } }`;

async function anilistDetail(malId: number): Promise<Anime | null> {
  try {
    const response = await fetch("https://graphql.anilist.co", { method: "POST", signal: AbortSignal.timeout(7000), headers: { "Content-Type": "application/json", "User-Agent": "Mozilla/5.0" }, body: JSON.stringify({ query: ANILIST_DETAIL, variables: { malId } }) });
    if (!response.ok) return null;
    const m = (await response.json())?.data?.Media;
    if (!m?.idMal) return null;
    const pad = (v?: number) => String(v || 1).padStart(2, "0");
    const status = m.status === "RELEASING" ? "currently_airing" : m.status === "NOT_YET_RELEASED" ? "not_yet_aired" : "finished_airing";
    return {
      id: m.idMal, title: m.title?.userPreferred || m.title?.romaji || "", image: m.coverImage?.large || "",
      score: m.averageScore ? m.averageScore / 10 : null, members: m.popularity || 0, synopsis: (m.description || "").replace(/<[^>]*>/g, " "),
      genres: m.genres || [], status, episodes: m.episodes || 0,
      startDate: m.startDate?.year ? `${m.startDate.year}-${pad(m.startDate.month)}-${pad(m.startDate.day)}` : "",
      endDate: m.endDate?.year ? `${m.endDate.year}-${pad(m.endDate.month)}-${pad(m.endDate.day)}` : "",
      season: m.season && m.startDate?.year ? `${m.season.toLowerCase()} ${m.startDate.year}` : "",
      mediaType: m.format || "", rating: "", source: m.source || "",
      studios: (m.studios?.nodes || []).map((s: { name: string }) => s.name), duration: (m.duration || 0) * 60,
      trailer: m.trailer?.site === "youtube" ? String(m.trailer.id || "") : "", alternativeTitle: m.title?.english || "",
      altTitles: [...(m.synonyms || []), m.title?.english || "", m.title?.romaji || ""].filter(Boolean),
      related: (m.relations?.edges || []).filter((e: { node: { idMal?: number | null; type?: string } }) => e.node?.idMal && e.node?.type === "ANIME").map((e: { relationType?: string; node: { idMal: number; title?: { userPreferred?: string }; coverImage?: { large?: string } } }) => ({ id: e.node.idMal, title: e.node.title?.userPreferred || "", image: e.node.coverImage?.large || "", relation: e.relationType || "Related" })).slice(0, 8),
    };
  } catch { return null; }
}

export async function getAnime(id: number): Promise<Anime | null> {
  const mal = await malFetch(`/anime/${id}?fields=${fields}`);
  if (mal?.id) return normalize(mal);
  const jikan = await jikanFetch(`/anime/${id}/full`);
  if (jikan?.data?.mal_id) return jikanNormalize(jikan.data);
  return anilistDetail(id);
}

export async function getRanking(type: "airing" | "bypopularity" | "all" = "airing", limit = 20): Promise<Anime[]> {
  const mal = await malFetch(`/anime/ranking?ranking_type=${type}&limit=${limit}&fields=${listFields}`);
  if (mal?.data?.length) return (mal.data as { node: MalNode }[]).map(item => normalize(item.node));
  const filter = type === "all" ? "" : `filter=${type}&`;
  const jikan = await jikanFetch(`/top/anime?${filter}limit=${limit}`);
  if (jikan?.data?.length) return (jikan.data as JikanItem[]).map(jikanNormalize);
  return [];
}

export type SeasonRef = { year: number; season: "winter" | "spring" | "summer" | "fall" };
export function currentSeason(d = new Date()): SeasonRef {
  const m = d.getUTCMonth();
  return { year: d.getUTCFullYear(), season: m < 3 ? "winter" : m < 6 ? "spring" : m < 9 ? "summer" : "fall" };
}
export function nextSeason(ref: SeasonRef = currentSeason()): SeasonRef {
  const order: SeasonRef["season"][] = ["winter", "spring", "summer", "fall"];
  const i = order.indexOf(ref.season);
  return i === 3 ? { year: ref.year + 1, season: "winter" } : { year: ref.year, season: order[i + 1] };
}

export async function getSeason(year: number, season: string, limit = 100): Promise<Anime[]> {
  const mal = await malFetch(`/anime/season/${year}/${season}?limit=${limit}&sort=anime_num_list_users&fields=${listFields}`);
  if (mal?.data?.length) return (mal.data as { node: MalNode }[]).map(item => normalize(item.node));
  const jikan = await jikanFetch(`/seasons/${year}/${season}?limit=${Math.min(limit, 25)}&sfw=true`);
  if (jikan?.data?.length) return (jikan.data as JikanItem[]).map(jikanNormalize);
  return [];
}

const ANILIST_QUERY = `query ($search: String) { Page(page: 1, perPage: 20) { media(search: $search, type: ANIME) { idMal title { userPreferred romaji english } coverImage { large } averageScore episodes format startDate { year } } } }`;

async function anilistSearch(query: string): Promise<Anime[]> {
  try {
    const response = await fetch("https://graphql.anilist.co", { method: "POST", signal: AbortSignal.timeout(7000), headers: { "Content-Type": "application/json", "User-Agent": "Mozilla/5.0" }, body: JSON.stringify({ query: ANILIST_QUERY, variables: { search: query } }) });
    if (!response.ok) return [];
    const json = await response.json();
    type Media = { idMal?: number | null; title?: { userPreferred?: string; romaji?: string; english?: string }; coverImage?: { large?: string }; averageScore?: number | null; episodes?: number | null; format?: string; startDate?: { year?: number | null } };
    return ((json?.data?.Page?.media || []) as Media[]).filter(m => m.idMal).map(m => ({
      id: m.idMal as number, title: m.title?.userPreferred || m.title?.romaji || "", image: m.coverImage?.large || "",
      score: m.averageScore ? m.averageScore / 10 : null, members: 0, synopsis: "", genres: [], status: "",
      episodes: m.episodes || 0, startDate: m.startDate?.year ? `${m.startDate.year}-01-01` : "", endDate: "", season: "",
      mediaType: m.format || "", rating: "", source: "", studios: [], duration: 0, trailer: "",
      alternativeTitle: m.title?.english || "", altTitles: [m.title?.english || "", m.title?.romaji || ""].filter(Boolean), related: [],
    }));
  } catch { return []; }
}

async function kuroiruSearch(query: string): Promise<Anime[]> {
  try {
    const response = await fetch("https://kuroiru.co/backend/search", { method: "POST", signal: AbortSignal.timeout(6000), headers: { "Content-Type": "application/x-www-form-urlencoded", "User-Agent": "Mozilla/5.0", "Accept": "application/json" }, body: new URLSearchParams({ q: query }).toString() });
    if (!response.ok || !(response.headers.get("content-type") || "").includes("json")) return [];
    const data = await response.json();
    if (!Array.isArray(data)) return [];
    return (data as { id?: number; title?: string; image?: string }[]).filter(item => item.id).slice(0, 20).map(item => ({
      id: item.id as number, title: item.title || "", image: item.image ? `https://kuroiru.co${item.image}` : "",
      score: null, members: 0, synopsis: "", genres: [], status: "", episodes: 0, startDate: "", endDate: "", season: "",
      mediaType: "", rating: "", source: "", studios: [], duration: 0, trailer: "", alternativeTitle: "", altTitles: [item.title || ""], related: [],
    }));
  } catch { return []; }
}

export async function searchAnime(query: string): Promise<Anime[]> {
  if (query.trim().length < 2) return [];
  const mal = await malFetch(`/anime?q=${encodeURIComponent(query.trim())}&limit=20&fields=${listFields}`);
  if (mal?.data?.length) return (mal.data as { node: MalNode }[]).map(item => normalize(item.node));
  const jikan = await jikanFetch(`/anime?q=${encodeURIComponent(query.trim())}&limit=20&sfw=true`);
  if (jikan?.data?.length) return (jikan.data as JikanItem[]).map(jikanNormalize);
  const anilist = await anilistSearch(query);
  if (anilist.length) return anilist;
  return kuroiruSearch(query);
}

export async function getCatalog() {
  const now = currentSeason();
  const next = nextSeason(now);
  const [seasonal, weekly, daily, upcomingSeason] = await Promise.all([
    getSeason(now.year, now.season, 100),
    getRanking("airing", 20),
    getRanking("bypopularity", 20),
    getSeason(next.year, next.season, 50),
  ]);
  const today = new Date().toISOString().slice(0, 10);
  const pool = [...new Map([...seasonal, ...upcomingSeason, ...weekly, ...daily].map(a => [a.id, a])).values()].filter(a => a.image);
  const upcoming = pool
    .filter(a => a.status === "not_yet_aired" || (a.startDate && a.startDate > today))
    .sort((a, b) => (a.startDate || "9999-12-31").localeCompare(b.startDate || "9999-12-31"))
    .slice(0, 60);
  const recent = pool
    .filter(a => a.status !== "not_yet_aired" && a.startDate && a.startDate <= today)
    .sort((a, b) => (b.startDate || "").localeCompare(a.startDate || ""))
    .slice(0, 60);
  const featured = [...seasonal].sort((a, b) => b.members - a.members)[0] || weekly[0] || null;
  const trending = weekly.length ? weekly.slice(0, 10) : [...seasonal].sort((a, b) => b.members - a.members).filter(a => a.image).slice(0, 10);
  const dailyTop = daily.length ? daily.slice(0, 10) : trending;
  return { now, pool, upcoming, recent, featured, trending, dailyTop };
}

export type AniZipEpisode = { number: number; title: string; image: string; airDate: string; overview: string };
export type AniZipData = { anilistId: number | null; anidbId: number | null; tvdbId: number | null; tmdbId: string | null; episodeCount: number; episodes: AniZipEpisode[]; titles: { en?: string; ja?: string; romaji?: string } };
export async function getAniZip(malId: number): Promise<AniZipData | null> {
  try {
    const response = await fetch(`https://api.ani.zip/mappings?mal_id=${malId}`, { next: { revalidate: 3600 } });
    if (!response.ok) return null;
    const data = await response.json();
    return {
      anilistId: data.mappings?.anilist_id || null,
      anidbId: data.mappings?.anidb_id || null,
      tvdbId: data.mappings?.thetvdb_id || null,
      tmdbId: data.mappings?.themoviedb_id || null,
      episodeCount: data.episodeCount || 0,
      episodes: Object.entries(data.episodes || {}).map(([key, value]) => {
        const ep = value as { episodeNumber?: number; title?: { en?: string; ja?: string }; image?: string; airDate?: string; overview?: string };
        return { number: ep.episodeNumber || Number(key), title: ep.title?.en || ep.title?.ja || `Episode ${key}`, image: ep.image || "", airDate: ep.airDate || "", overview: ep.overview || "" };
      }).filter(ep => Number.isFinite(ep.number)).sort((a,b) => a.number - b.number),
      titles: { en: data.titles?.en, ja: data.titles?.ja, romaji: data.titles?.["x-jat"] },
    };
  } catch { return null; }
}
