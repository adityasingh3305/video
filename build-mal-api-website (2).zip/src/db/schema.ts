import { pgTable, serial, varchar, integer, timestamp, uniqueIndex } from "drizzle-orm/pg-core";

export const watchlist = pgTable("watchlist", {
  id: serial("id").primaryKey(),
  visitorId: varchar("visitor_id", { length: 100 }).notNull(),
  animeId: integer("anime_id").notNull(),
  status: varchar("status", { length: 30 }).notNull().default("Watching"),
  title: varchar("title", { length: 300 }).notNull().default(""),
  image: varchar("image", { length: 500 }).notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => [uniqueIndex("watchlist_visitor_anime_idx").on(table.visitorId, table.animeId)]);
