import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

// Lazily created so importing this module never throws at build time (B6).
const globalForDb = globalThis as typeof globalThis & { __kuroiruPool?: Pool; __kuroiruDb?: NodePgDatabase<typeof schema> };

export function getDb(): NodePgDatabase<typeof schema> {
  if (!globalForDb.__kuroiruDb) {
    const url = process.env.DATABASE_URL;
    if (!url) throw new Error("DATABASE_URL is required");
    globalForDb.__kuroiruPool = globalForDb.__kuroiruPool ?? new Pool({ connectionString: url });
    globalForDb.__kuroiruDb = drizzle(globalForDb.__kuroiruPool, { schema });
  }
  return globalForDb.__kuroiruDb;
}
