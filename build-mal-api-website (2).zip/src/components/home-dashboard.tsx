"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRight, BarChart3, Bell, CalendarDays, ChevronDown, ChevronLeft, ChevronRight, Grid2X2, List as ListIcon, RefreshCw, Search, SlidersHorizontal, Trash2, UserRound, X } from "lucide-react";
import type { Anime } from "@/lib/anime";

type SavedItem = { id: number; animeId: number; status: string; title: string; image: string };
const statuses = ["Watching", "Completed", "Plan to Watch", "On Hold", "Dropped"];
export function count(n: number) { return n >= 1000000 ? `${(n / 1000000).toFixed(1)}M` : n >= 1000 ? `${Math.round(n / 1000)}K` : String(n); }
export function title(anime: Anime) { return anime.alternativeTitle && anime.alternativeTitle.length < 56 ? anime.alternativeTitle : anime.title; }
function niceDate(value: string) { const d = new Date(`${value.slice(0, 10)}T00:00:00Z`); return Number.isNaN(d.getTime()) ? "TBA" : d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }); }

export function dayDiff(dateStr: string): number | null {
  if (!dateStr) return null;
  const time = new Date(`${dateStr.slice(0, 10)}T00:00:00Z`).getTime();
  if (Number.isNaN(time)) return null;
  return Math.round((time - Date.now()) / 86400000);
}
export function footFor(mode: "upcoming" | "recent", anime: Anime): string {
  const diff = dayDiff(anime.startDate);
  if (mode === "upcoming") {
    if (diff === null) return "TBA";
    if (diff <= 0) return "just released";
    if (diff === 1) return "next 1 day";
    return `next ${diff} days`;
  }
  if (diff === null) return "recent";
  if (diff >= 0) return "just released";
  const past = -diff;
  return past === 1 ? "1 day ago" : `${past} days ago`;
}
export function badgeFor(mode: "upcoming" | "recent", anime: Anime): string {
  const episodes = anime.episodes;
  if (mode === "recent") return episodes ? `${episodes}/${episodes}` : "?/?";
  return episodes ? `0/${episodes}` : "?/?";
}

function AnimeCard({ anime, mode }: { anime: Anime; mode: "upcoming" | "recent" }) {
  return <Link href={`/anime/${anime.id}`} className="anime-card" aria-label={`View ${title(anime)}`}>
    <div className="poster-frame">
      {anime.image ? <img src={anime.image} alt={`${title(anime)} poster`} loading="lazy" /> : <div className="poster-empty" />}
      <span className="poster-top">{anime.score ? anime.score.toFixed(2) : "?"} ♙ {count(anime.members)}</span>
      <span className="poster-count">{badgeFor(mode, anime)}</span>
    </div>
    <div className="card-caption"><span className="card-title">{title(anime)}</span><span className="card-foot">{footFor(mode, anime)}</span></div>
  </Link>;
}

const PREVIEW = 8;

function Rail({ heading, countLabel, anime, mode, tools, href }: { heading: string; countLabel: string; anime: Anime[]; mode: "upcoming" | "recent"; tools?: React.ReactNode; href: string }) {
  const ref = useRef<HTMLDivElement>(null);
  return <section className="rail-section">
    <div className="section-heading">
      <h2>{heading} <span>{countLabel}</span></h2>
      <div className="rail-tools">
        {tools}
        {anime.length > PREVIEW && <Link href={href} className="view-all">View all ({anime.length})</Link>}
      </div>
    </div>
    <div className="rail-wrap">
      <div className="anime-rail" ref={ref}>{anime.slice(0, PREVIEW).map((a, i) => <AnimeCard key={`${a.id}-${i}`} anime={a} mode={mode} />)}</div>
      <button className="rail-next" aria-label={`Scroll ${heading}`} onClick={() => ref.current?.scrollBy({ left: 465, behavior: "smooth" })}><ChevronRight size={23} /></button>
    </div>
  </section>;
}

export function HomeDashboard({ featured, upcoming, recent, weekly, daily, seasonLabel }: { featured: Anime | null; upcoming: Anime[]; recent: Anime[]; weekly: Anime[]; daily: Anime[]; seasonLabel: string }) {
  const router = useRouter();
  const seen = new Set<number>();
  const heroes = [featured, ...upcoming, ...recent].filter((a): a is Anime => { if (!a || seen.has(a.id)) return false; seen.add(a.id); return true; });
  const [heroIndex, setHeroIndex] = useState(0);
  const [rankMode, setRankMode] = useState<"Weekly" | "Daily">("Weekly");
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Anime[]>([]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [browseMode, setBrowseMode] = useState(false);
  const [searchError, setSearchError] = useState(false);
  const [listStatus, setListStatus] = useState("Watching");
  const [listView, setListView] = useState<"List" | "Grid" | "Details">("List");
  const [sortMode, setSortMode] = useState<"edited" | "title">("edited");
  const [saved, setSaved] = useState<SavedItem[]>([]);
  const [visitorId, setVisitorId] = useState("");
  const [listNotice, setListNotice] = useState("");
  const [notification, setNotification] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const [history, setHistory] = useState<{ id: number; title: string; image: string }[]>([]);
  const activeHero = heroes[heroIndex % Math.max(heroes.length, 1)];
  const topics = [seasonLabel, "Hip-hop Music", "Baseball", "E-Sports", "Samurai", "Urban Fantasy", "Gore", "Office Lady"];
  useEffect(() => {
    let id = localStorage.getItem("kuroiru-visitor");
    if (!id) { id = crypto.randomUUID(); localStorage.setItem("kuroiru-visitor", id); }
    setVisitorId(id);
    fetch(`/api/list?visitorId=${encodeURIComponent(id)}`).then(r => r.ok ? r.json() : Promise.reject(new Error("list unavailable"))).then(d => setSaved(d.items || [])).catch(() => setListNotice("Your list could not be loaded right now."));
    const q = new URLSearchParams(window.location.search).get("q");
    if (q) { setQuery(q); setSearchOpen(true); setBrowseMode(false); }
    try { setHistory(JSON.parse(localStorage.getItem("kuroiru-history") || "[]")); } catch { setHistory([]); }
  }, []);
  useEffect(() => {
    function focusSearch(event: KeyboardEvent) {
      const target = event.target as HTMLElement;
      if (event.key.toLowerCase() === "f" && !event.ctrlKey && !event.metaKey && !["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) {
        event.preventDefault();
        document.querySelector<HTMLInputElement>(".search-box input")?.focus();
        setSearchOpen(true);
      }
    }
    document.addEventListener("keydown", focusSearch);
    return () => document.removeEventListener("keydown", focusSearch);
  }, []);
  useEffect(() => {
    if (browseMode || query.trim().length < 2) { setResults([]); setSearchError(false); return; }
    const controller = new AbortController();
    const timer = setTimeout(() => fetch(`/api/search?q=${encodeURIComponent(query.trim())}`, { signal: controller.signal }).then(r => { if (!r.ok) throw new Error("search failed"); return r.json(); }).then(d => { setResults(d.results || []); setSearchError(false); }).catch(e => { if (e.name !== "AbortError") { setResults([]); setSearchError(true); } }), 250);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [query, browseMode]);
  const listItems = saved.filter(item => item.status === listStatus).sort((a, b) => sortMode === "title" ? (a.title || `Anime #${a.animeId}`).localeCompare(b.title || `Anime #${b.animeId}`) : 0);
  const ranking = rankMode === "Weekly" ? weekly : daily;
  const shownResults = browseMode ? weekly.slice(0, 7) : results;
  async function removeItem(item: SavedItem) {
    const response = await fetch("/api/list", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ visitorId, animeId: item.animeId }) });
    if (response.ok) setSaved(saved.filter(s => s.id !== item.id));
    else setListNotice("Could not remove the entry. Please try again.");
  }
  return <div className="site-shell">
    <header className="topbar"><Link href="/" className="brand" aria-label="Kuroiru home">Kuroiru</Link>
      <div className="search-area"><div className="search-box"><input value={query} onChange={e => { setQuery(e.target.value); setSearchOpen(true); setBrowseMode(false); }} onFocus={() => setSearchOpen(true)} onKeyDown={e => { if (e.key === "Escape") setSearchOpen(false); if (e.key === "Enter" && query.trim().length > 1) fetch(`/api/search?q=${encodeURIComponent(query.trim())}`).then(r => r.json()).then(d => { if (d.results?.[0]) router.push(`/anime/${d.results[0].id}`); }).catch(() => setSearchError(true)); }} placeholder="Search anime (F)" aria-label="Search anime" /><button title="Browse trending anime" onClick={() => { setBrowseMode(!browseMode); setSearchOpen(true); }}><Grid2X2 size={17} /></button><button title="Search" onClick={() => { setBrowseMode(false); setSearchOpen(!searchOpen); document.querySelector<HTMLInputElement>(".search-box input")?.focus(); }}><Search size={18} /></button></div>
        {searchOpen && <div className="search-results"><div className="dropdown-title">{browseMode ? "Trending on MAL" : "Anime results"} <button onClick={() => setSearchOpen(false)} aria-label="Close search"><X size={15} /></button></div>{browseMode ? shownResults.map(a => <Link key={a.id} href={`/anime/${a.id}`}>{a.image ? <img src={a.image} alt="" /> : <div className="result-thumb-empty" />}<span>{title(a)}<small>{a.season || a.mediaType.toUpperCase() || "ANIME"} · ★ {a.score ? a.score.toFixed(2) : "—"}</small></span></Link>) : query.trim().length > 1 ? (searchError ? <p className="empty-search">Search is unavailable right now.</p> : results.length ? results.slice(0, 7).map(a => <Link key={a.id} href={`/anime/${a.id}`}>{a.image ? <img src={a.image} alt="" /> : <div className="result-thumb-empty" />}<span>{title(a)}<small>{a.season || a.mediaType.toUpperCase() || "ANIME"} · ★ {a.score ? a.score.toFixed(2) : "—"}</small></span></Link>) : <p className="empty-search">No matches found.</p>) : <p className="empty-search">Type at least 2 characters to search MAL, AniList and Kuroiru.</p>}</div>}
      </div><div className="header-actions"><button aria-label="Notifications" onClick={() => { setNotification(!notification); setShowProfile(false); }}><Bell size={20} /></button><button aria-label="Profile" onClick={() => { setShowProfile(!showProfile); setNotification(false); }}><UserRound size={20} /></button></div>
      {notification && <div className="header-popover">You&apos;re all caught up. New anime appears here as MAL updates.</div>}{showProfile && <div className="header-popover profile-popover">Your list is saved on this browser. Add an anime to get started.</div>}
    </header>
    {activeHero && <section className="hero" style={{ backgroundImage: `linear-gradient(90deg, #202427 0%, rgba(30,34,36,.94) 35%, rgba(22,23,24,.76) 100%), linear-gradient(0deg, #151515, transparent), url(${JSON.stringify(activeHero.image)})` }}>
      <Link href={`/anime/${activeHero.id}`} className="hero-poster">{activeHero.image ? <img src={activeHero.image} alt={`${title(activeHero)} poster`} /> : <div className="poster-empty" />}</Link><div className="hero-content"><Link href={`/anime/${activeHero.id}`}><h1>{title(activeHero)}</h1></Link><p className="hero-meta">☆ {activeHero.score || "?"} ♙ {activeHero.members.toLocaleString()}</p><p className="hero-summary">{activeHero.synopsis.replace(/<[^>]*>/g, " ").slice(0, 200)}{activeHero.synopsis.length > 200 ? "..." : ""}</p><p className="hero-genres">{activeHero.genres.slice(0, 4).join(", ")}</p><div className="hero-controls"><button aria-label="Previous featured anime" onClick={() => setHeroIndex((heroIndex + heroes.length - 1) % heroes.length)}><ChevronLeft size={17} /></button><span>{heroIndex + 1} / {heroes.length}</span><button aria-label="Next featured anime" onClick={() => setHeroIndex((heroIndex + 1) % heroes.length)}><ChevronRight size={17} /></button></div></div><div className="hero-dots">{heroes.map((_, i) => <button key={i} aria-label={`Feature ${i + 1}`} className={heroIndex === i ? "active" : ""} onClick={() => setHeroIndex(i)} />)}</div>
    </section>}
    <div className="main-columns"><main className="main-content">
      <section className="explore-section"><div className="section-heading"><h2>Explore Anime <RefreshCw className="subtle-icon" size={18} /></h2><Link href="/explore" className="icon-square" aria-label="Explore anime"><ArrowRight size={21} /></Link></div><div className="topic-row">{topics.map((topic, i) => <button key={topic} className={`topic topic-${i}`} onClick={() => { setQuery(topic === seasonLabel ? seasonLabel.toLowerCase() : topic); setBrowseMode(false); setSearchOpen(true); document.querySelector<HTMLInputElement>(".search-box input")?.focus(); }}>{topic}</button>)}</div></section>
      <Rail heading="Upcoming" countLabel={String(upcoming.length)} anime={upcoming} mode="upcoming" href="/upcoming" tools={<div className="segmented"><button className={!showCalendar ? "selected" : ""} onClick={() => setShowCalendar(false)}>Now</button><button className={showCalendar ? "selected" : ""} onClick={() => setShowCalendar(true)}><CalendarDays size={14} /> Calendar</button></div>} />
      {showCalendar && <div className="cal-panel">{upcoming.slice(0, 6).map(a => <div key={a.id}><span>{niceDate(a.startDate)}</span><Link href={`/anime/${a.id}`}>{title(a)}</Link></div>)}{upcoming.length === 0 && <p>No upcoming dates announced yet.</p>}</div>}
      <Rail heading="Recently Released" countLabel={String(recent.length)} anime={recent} mode="recent" href="/recent" />
    </main><aside className="sidebar"><div className="trend-heading"><h2>Trending</h2><div className="segmented"><button onClick={() => setRankMode("Weekly")} className={rankMode === "Weekly" ? "selected" : ""}>Weekly</button><button onClick={() => setRankMode("Daily")} className={rankMode === "Daily" ? "selected" : ""}>Daily</button></div></div><div className="trending-list">{ranking.map((a, i) => <Link href={`/anime/${a.id}`} className="trend-item" key={a.id}>{a.image ? <img src={a.image} alt="" /> : <div className="trend-thumb-empty" />}<div className="trend-info"><span className="trend-name">{title(a)}</span><div className="trend-meta"><span>#{i + 1} │ {count(a.members)} members</span><span>★ {a.score?.toFixed(2) || "?"}</span></div></div></Link>)}</div><button className="trend-more" onClick={() => setRankMode(rankMode === "Weekly" ? "Daily" : "Weekly")} aria-label="Switch trending ranking"><ChevronDown size={18} /></button><div className="history-title"><h2>My History</h2><button title="Clear history" onClick={() => { localStorage.setItem("kuroiru-history", "[]"); setHistory([]); }}><Trash2 size={19} /></button></div>{history.length ? <div className="hist-list">{history.slice(0, 6).map(h => <Link key={h.id} href={`/anime/${h.id}`} className="hist-row">{h.image ? <img src={h.image} alt="" /> : <div className="trend-thumb-empty" />}<span>{h.title}</span></Link>)}</div> : <p className="history-empty-note side-note">Anime you open or stream will appear here.</p>}</aside></div>
    <section className="my-list"><div className="my-list-heading"><h2>My List <ArrowRight size={20} /></h2><span className="stats-toggle"><button onClick={() => setShowStats(!showStats)}><BarChart3 size={15} /> Stats</button>{showStats && <span className="stats-popover">{statuses.map(s => <span key={s}>{s}: {saved.filter(i => i.status === s).length}</span>)}</span>}</span></div><div className="list-toolbar"><select value={listStatus} onChange={e => setListStatus(e.target.value)} aria-label="Filter list status">{statuses.map(s => <option key={s}>{s}</option>)}</select><div className="list-right"><span className="sort-span"><SlidersHorizontal size={15} /><select value={sortMode} onChange={e => setSortMode(e.target.value as "edited" | "title")} aria-label="Sort list"><option value="edited">Last edited</option><option value="title">Title A–Z</option></select></span><div className="segmented">{(["List", "Grid", "Details"] as const).map(v => <button key={v} onClick={() => setListView(v)} className={listView === v ? "selected" : ""}>{v}</button>)}</div></div></div>{listNotice && <p className="list-notice" role="status">{listNotice}</p>}<div className={`saved-grid view-${listView.toLowerCase()}`}>{listItems.length ? listItems.map(item => <div key={item.id} className="saved-card"><Link href={`/anime/${item.animeId}`}>{item.image ? <img src={item.image} alt={`${item.title || `Anime #${item.animeId}`} poster`} /> : <div className="saved-thumb-empty" />}<span>{item.title || `Anime #${item.animeId}`}</span></Link><button aria-label="Remove from list" onClick={() => removeItem(item)}><X size={16} /></button></div>) : <><div className="list-placeholder" /><div className="list-placeholder" /></>}</div></section>
    <footer className="site-footer"><div><span>Kuroiru.co</span><div><a href="/about">About</a><a href="/explore">Explore</a><a href="/terms">Terms</a></div></div><div className="socials"><span>Socials</span><div className="social-links"><a href="https://myanimelist.net" target="_blank" rel="noopener noreferrer" title="MyAnimeList">MAL</a><a href="https://anilist.co" target="_blank" rel="noopener noreferrer" title="AniList">AniList</a><a href="https://ani.zip" target="_blank" rel="noopener noreferrer" title="AniZip">AniZip</a></div></div></footer>
  </div>;
}
