"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, ChevronDown, ChevronLeft, ChevronRight, ExternalLink, Link2, MessageSquare, Pencil, Play, Check } from "lucide-react";
import type { Anime, AniZipData } from "@/lib/anime";
import type { ResolvedLink } from "@/lib/providers/core";

type Tab = "STREAMS" | "INFO" | "RELATED" | "MUSIC" | "NEWS";
const tabs: Tab[] = ["STREAMS", "INFO", "RELATED", "MUSIC", "NEWS"];
const statuses = ["Watching", "Completed", "Plan to Watch", "On Hold", "Dropped"];
function niceTitle(a: Anime) { return a.alternativeTitle && a.alternativeTitle.length < 65 ? a.alternativeTitle : a.title; }
function date(value: string) { if (!value) return "TBA"; const parsed = new Date(`${value}T00:00:00`); return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }); }
function format(value: string) { return value ? value.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()) : "Unknown"; }

export function AnimeDetail({ anime, mapping }: { anime: Anime; mapping: AniZipData | null }) {
  const latestAired = (mapping?.episodes || []).filter(e => e.airDate && new Date(e.airDate).getTime() <= Date.now()).pop()?.number;
  const [tab, setTab] = useState<Tab>("STREAMS");
  const [episode, setEpisode] = useState(Math.max(1, latestAired || 1));
  const [epPage, setEpPage] = useState(0);
  const [showEpisodes, setShowEpisodes] = useState(false);
  const [status, setStatus] = useState("");
  const [visitorId, setVisitorId] = useState("");
  const [showStatus, setShowStatus] = useState(false);
  const [savedMessage, setSavedMessage] = useState("");
  const [hideSpecials, setHideSpecials] = useState(true);
  const [links, setLinks] = useState<ResolvedLink[] | null>(null);
  const [linksError, setLinksError] = useState(false);
  const [themes, setThemes] = useState<{ openings: string[]; endings: string[] } | null>(null);
  const selectedEpisode = mapping?.episodes.find(e => e.number === episode);
  const episodeTotal = mapping?.episodeCount || anime.episodes || mapping?.episodes.length || 0;
  function recordHistory() {
    try {
      const previous: { id: number; title: string; image: string }[] = JSON.parse(localStorage.getItem("kuroiru-history") || "[]");
      localStorage.setItem("kuroiru-history", JSON.stringify([{ id: anime.id, title: anime.title, image: anime.image }, ...previous.filter(p => p.id !== anime.id)].slice(0, 12)));
    } catch { /* history is best-effort */ }
  }
  useEffect(() => {
    let id = localStorage.getItem("kuroiru-visitor");
    if (!id) { id = crypto.randomUUID(); localStorage.setItem("kuroiru-visitor", id); }
    setVisitorId(id);
    fetch(`/api/list?visitorId=${encodeURIComponent(id)}`).then(r => r.json()).then(d => { const entry = d.items?.find((item: { animeId: number }) => item.animeId === anime.id); if (entry) setStatus(entry.status); }).catch(() => {});
    recordHistory();
  }, [anime.id]);
  useEffect(() => {
    if (tab !== "STREAMS") return;
    let cancelled = false;
    setLinks(null); setLinksError(false);
    fetch(`/api/streams?malId=${anime.id}&episode=${episode}`).then(r => { if (!r.ok) throw new Error("streams failed"); return r.json(); }).then(d => { if (!cancelled) setLinks(d.links || []); }).catch(() => { if (!cancelled) { setLinks([]); setLinksError(true); } });
    return () => { cancelled = true; };
  }, [tab, episode, anime.id]);
  useEffect(() => {
    if (tab !== "MUSIC") return;
    let cancelled = false;
    setThemes(null);
    fetch(`/api/themes?id=${anime.id}`).then(r => r.ok ? r.json() : { openings: [], endings: [] }).then(d => { if (!cancelled) setThemes({ openings: d.openings || [], endings: d.endings || [] }); }).catch(() => { if (!cancelled) setThemes({ openings: [], endings: [] }); });
    return () => { cancelled = true; };
  }, [tab, anime.id]);
  async function save(nextStatus: string) {
    const response = await fetch("/api/list", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ visitorId, animeId: anime.id, status: nextStatus, title: anime.title, image: anime.image }) });
    if (response.ok) { setStatus(nextStatus); setSavedMessage(`Added to ${nextStatus}`); setTimeout(() => setSavedMessage(""), 3000); }
    else setSavedMessage("Could not save your list. Please try again.");
    setShowStatus(false);
  }
  const resolvedLinks = (links || []).filter(l => l.url);
  const unresolvedLinks = (links || []).filter(l => !l.url);
  const fallbackSearch = (l: ResolvedLink) => `https://www.google.com/search?q=${encodeURIComponent(`${l.name} watch ${niceTitle(anime)} episode ${episode}`)}`;
  const gridEpisodes = Array.from({ length: Math.min(Math.max(episodeTotal - epPage * 100, 0) || 12, 100) }, (_, i) => epPage * 100 + i + 1);
  return <div className="detail-outer"><div className="detail-shell">
    <div className="detail-back"><Link href="/" aria-label="Back to home"><ArrowLeft size={27} strokeWidth={1.4} /></Link></div>
    <div className="detail-title"><h1>{niceTitle(anime)}</h1><p>{anime.title}{anime.alternativeTitle && anime.alternativeTitle !== anime.title ? `, ${anime.alternativeTitle}` : ""}</p></div>
    <div className="detail-layout"><aside className="detail-aside"><div className="cover-wrap">{anime.image ? <img src={anime.image} alt={`${niceTitle(anime)} cover`} /> : <div className="cover-empty" />}<div className="cover-actions"><button disabled={!visitorId} onClick={() => setShowStatus(!showStatus)}>{status ? <><Check size={13} /> {status}</> : "Add to List"}</button><button className="edit-action" aria-label="Choose list status" disabled={!visitorId} onClick={() => setShowStatus(!showStatus)}><Pencil size={12} /></button></div>{showStatus && <div className="status-popover">{statuses.map(s => <button key={s} onClick={() => save(s)}>{s}</button>)}</div>}</div><button className="side-streams" onClick={() => { setTab("STREAMS"); window.scrollTo({ top: 0, behavior: "smooth" }); }}>Streams</button>{savedMessage && <p className="saved-message" role="status" aria-live="polite">{savedMessage}</p>}</aside>
      <div className="detail-main"><div className="detail-tabs" role="tablist" aria-label="Anime details">{tabs.map(t => <button key={t} role="tab" aria-selected={tab === t} className={tab === t ? "active" : ""} onClick={() => setTab(t)}>{t}</button>)}</div>
      {tab === "STREAMS" && <div className="streams-panel"><div className="episode-toolbar"><div className="episode-select"><button className="episode-range" onClick={() => setShowEpisodes(!showEpisodes)}>1–{episodeTotal || "?"}</button><button className="episode-current" onClick={() => setShowEpisodes(!showEpisodes)}>{episode}</button></div><span className="air-timer">{selectedEpisode?.airDate ? `Aired ${date(selectedEpisode.airDate.slice(0, 10))}` : `${episodeTotal || "?"} episodes`}</span></div>
        {showEpisodes && <div className="episode-grid">{episodeTotal > 100 && <div className="ep-pages"><button disabled={epPage === 0} onClick={() => setEpPage(epPage - 1)} aria-label="Previous episode page"><ChevronLeft size={14} /></button><span>{epPage * 100 + 1}–{Math.min(episodeTotal, (epPage + 1) * 100)}</span><button disabled={(epPage + 1) * 100 >= episodeTotal} onClick={() => setEpPage(epPage + 1)} aria-label="Next episode page"><ChevronRight size={14} /></button></div>}{gridEpisodes.map(n => <button className={n === episode ? "active" : ""} key={n} onClick={() => { setEpisode(n); setShowEpisodes(false); }}>{n}</button>)}</div>}
        <div className="episode-nav"><button disabled={episode <= 1} onClick={() => setEpisode(episode - 1)}><ChevronLeft size={15} /></button><span>EP {episode}</span><button disabled={episodeTotal > 0 && episode >= episodeTotal} onClick={() => setEpisode(episode + 1)}><ChevronRight size={15} /></button></div>
        {selectedEpisode && <div className="episode-feature">{selectedEpisode.image ? <img src={selectedEpisode.image} alt={`Episode ${episode} still`} /> : null}<div><strong>Episode {episode}{selectedEpisode.title && selectedEpisode.title !== `Episode ${episode}` ? ` · ${selectedEpisode.title}` : ""}</strong>{selectedEpisode.overview && <p>{selectedEpisode.overview}</p>}</div></div>}
        <div className="stream-heading"><h2>Favorites</h2><span>resolved automatically</span></div><p className="stream-disclaimer">Watch URLs are resolved per provider from the MAL + AniZip identity and cached — nothing is maintained by hand. AniZip supplies episode metadata, not video.</p><div className="watch-links">{links === null ? [0,1,2,3].map(i => <span key={i} className="watch-chip skeleton" aria-hidden="true"><span className="chip-ep">EP ·</span><span className="chip-dot" />·····</span>) : resolvedLinks.map(l => <a key={l.provider} className="watch-chip" href={l.url as string} target="_blank" rel="noopener noreferrer" onClick={recordHistory}><span className="chip-ep">EP {l.epSupported ? episode : "?"}</span><span className="chip-dot" style={{ background: l.color }} />{l.name}<ExternalLink size={12} /></a>)}{linksError && <span className="chip-note">Provider resolver is unreachable right now.</span>}</div>
        <div className="section-divider"><span><ChevronDown size={13} /> All</span></div>{unresolvedLinks.length > 0 && <div className="watch-links">{unresolvedLinks.map(l => <a key={l.provider} className="watch-chip dashed" href={fallbackSearch(l)} target="_blank" rel="noopener noreferrer" title={`${l.name} id could not be resolved — search instead`} onClick={recordHistory}><span className="chip-ep">EP ?</span><span className="chip-dot" style={{ background: l.color }} />{l.name}</a>)}</div>}
        <p className="source-name">AniZip episode metadata</p><div className="comment-button"><MessageSquare size={14} /> {mapping?.episodes.length || 0} episodes indexed</div>
      </div>}
      {tab === "INFO" && <div className="info-panel"><div className="stats-bar"><div><small className="score-label">MAL Score</small><strong>{anime.score?.toFixed(2) || "N/A"}</strong></div><div><small>Members :</small><span>♙ {anime.members.toLocaleString()}</span></div><div><small>Type :</small><span>{anime.episodes || "?"} {anime.mediaType.toUpperCase() || "TV"}</span></div><div><small>Duration :</small><span>{anime.duration ? Math.round(anime.duration / 60) : "?"} min / ep</span></div></div><div className="info-top"><div className="facts"><div>Start : <span>{date(anime.startDate)}</span></div><div>End : <span>{date(anime.endDate)}</span></div><div>Season : <span>{format(anime.season)}</span></div><div>Rating : <span>{format(anime.rating)}</span></div><div>Genres : <span className="link-color">{anime.genres.join(", ") || "—"}</span></div><div>Source : <span className="link-color">{format(anime.source)}</span></div><div>Studio : <span className="link-color">{anime.studios.join(", ") || "—"}</span></div></div><div className="resources-mini"><ResourceLinks anime={anime} mapping={mapping} /></div></div>
        {anime.trailer && <div className="trailer-row"><a href={`https://www.youtube.com/watch?v=${anime.trailer}`} target="_blank" rel="noopener noreferrer"><Play size={14} fill="red" color="red" /> Trailer</a></div>}
        <section className="info-section"><h2>Synopsis</h2><p>{anime.synopsis.replace(/<[^>]*>/g, " ") || "No synopsis is available yet."}</p></section>
        <section className="info-section"><h2>Tags</h2><div className="tag-list">{anime.genres.length ? anime.genres.map(g => <span key={g}>{g} <small>genre</small></span>) : <span>Tags not available</span>}</div></section>
        <section className="info-section"><h2>Production</h2><div className="production-grid"><div><small>Studio</small><span>{anime.studios.join(", ") || "Unknown"}</span></div><div><small>Source</small><span>{format(anime.source)}</span></div><div><small>Format</small><span>{format(anime.mediaType)}</span></div><div><small>Status</small><span>{format(anime.status)}</span></div></div></section>
        <section className="info-section"><h2>Similar with</h2>{anime.related.length ? <div className="related-mini">{anime.related.slice(0, 3).map((r, i) => <Link href={`/anime/${r.id}`} key={`${r.id}-${r.relation}-${i}`}>{r.title}</Link>)}</div> : <p className="muted">No related anime listed on MAL.</p>}</section><section className="info-section"><h2>Collections</h2><a className="collection-card" href={`https://myanimelist.net/anime/${anime.id}`} target="_blank" rel="noopener noreferrer">{anime.image ? <img src={anime.image} alt="" /> : <div className="rel-thumb-empty" />}<div><strong>{niceTitle(anime)} on MyAnimeList</strong><p>Explore community reviews, recommendations and staff information.</p><small>{anime.members.toLocaleString()} members</small></div></a></section>
      </div>}
      {tab === "RELATED" && <div className="related-panel">{anime.related.length ? <><div className="related-summary">{anime.related.map((r, i) => <Link href={`/anime/${r.id}`} key={`${r.id}-${r.relation}-${i}`}><strong>{r.relation}</strong><span>{r.title}</span></Link>)}</div><div className="release-heading"><h2>Full release order</h2><label><input type="checkbox" checked={hideSpecials} onChange={e => setHideSpecials(e.target.checked)} /> Hide Specials</label></div><p className="related-series">{niceTitle(anime)} — related entries from MAL</p><div className="release-list">{anime.related.filter(r => !hideSpecials || !/special|summary|side story/i.test(r.relation + r.title)).map((r, i) => <Link href={`/anime/${r.id}`} key={`${r.id}-${r.relation}-${i}`}>{r.image ? <img src={r.image} alt="" /> : <div className="rel-thumb-empty" />}<div><span>{i + 1}. {r.title}</span><small>{r.relation}</small></div></Link>)}<div className="current-release">{anime.image ? <img src={anime.image} alt="" /> : <div className="rel-thumb-empty" />}<div><span>{niceTitle(anime)}</span><small>{anime.mediaType.toUpperCase()} {anime.episodes || "?"} × {anime.duration ? Math.round(anime.duration / 60) : 24} min<br />{date(anime.startDate)}</small></div><span className="current-here">You&apos;re here</span></div></div></> : <div className="no-related"><h2>Related anime</h2><p>No related entries are currently listed for this title.</p></div>}</div>}
      {tab === "MUSIC" && <div className="other-panel"><h2>Music</h2>{themes === null ? <p className="muted">Loading themes…</p> : themes.openings.length || themes.endings.length ? <div className="themes-list"><div>{themes.openings.map(t => <span key={t}>OP · {t.replace(/^"|"$/g, "")}</span>)}</div><div>{themes.endings.map(t => <span key={t}>ED · {t.replace(/^"|"$/g, "")}</span>)}</div></div> : <p>Opening and ending themes are not available for this title.</p>}<a href={`https://myanimelist.net/anime/${anime.id}`} target="_blank" rel="noopener noreferrer">View music on MyAnimeList <ExternalLink size={14} /></a></div>}
      {tab === "NEWS" && <div className="other-panel"><h2>News</h2><p>Read the latest community news and discussions about {niceTitle(anime)}.</p><a href={`https://myanimelist.net/anime/${anime.id}/_/news`} target="_blank" rel="noopener noreferrer">News on MyAnimeList <ExternalLink size={14} /></a></div>}
      </div></div><div className="detail-footer"><span>Other resources :</span><ResourceLinks anime={anime} mapping={mapping} /></div>
  </div></div>;
}
function ResourceLinks({ anime, mapping }: { anime: Anime; mapping: AniZipData | null }) {
  return <div className="resource-links"><a title="AniZip API (JSON)" href={`https://api.ani.zip/mappings?mal_id=${anime.id}`} target="_blank" rel="noopener noreferrer"><Link2 size={14} /></a>{mapping?.anilistId && <a title="AniList" href={`https://anilist.co/anime/${mapping.anilistId}`} target="_blank" rel="noopener noreferrer" className="resource-anilist">ani<br />list</a>}<a title="Anime News Network search" href={`https://www.animenewsnetwork.com/search?cx=016604166282602569737%3Aznd1ysjewre&q=${encodeURIComponent(anime.title)}`} target="_blank" rel="noopener noreferrer">🌐</a><a title="Wikipedia search" href={`https://en.wikipedia.org/w/index.php?search=${encodeURIComponent(anime.title)}`} target="_blank" rel="noopener noreferrer" className="resource-wiki">W</a><a title="MyAnimeList" href={`https://myanimelist.net/anime/${anime.id}`} target="_blank" rel="noopener noreferrer" className="resource-mal">MAL</a></div>;
}
