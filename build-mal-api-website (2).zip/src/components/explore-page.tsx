"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Bell, CalendarDays, ChevronsUpDown, FlaskConical, History, Search, Tags, Trash2, UserRound } from "lucide-react";

type MiniAnime = { id: number; title: string; image: string; genres?: string[] };
type HistoryItem = { id: number; title: string; image: string };
const genres = ["Action", "Adventure", "Comedy", "Drama", "Fantasy", "Horror", "Mystery", "Romance", "Sci-Fi", "Slice of Life", "Sports", "Supernatural"];
const seasons = ["winter", "spring", "summer", "fall"];
const years = Array.from({ length: 4 }, (_, i) => new Date().getUTCFullYear() - i);

export function ExplorePage() {
  const [tab, setTab] = useState<"Anime" | "Manga">("Anime");
  const [panel, setPanel] = useState<"tags" | "seasons" | "recs" | "sequel" | null>(null);
  const [items, setItems] = useState<MiniAnime[]>([]);
  const [loading, setLoading] = useState(false);
  const [genre, setGenre] = useState("");
  const [year, setYear] = useState(new Date().getUTCFullYear());
  const [season, setSeason] = useState("summer");
  const [sequelQuery, setSequelQuery] = useState("");
  const [sequelResults, setSequelResults] = useState<MiniAnime[]>([]);
  const [related, setRelated] = useState<{ id: number; title: string; image: string; relation: string }[]>([]);
  const [relatedTitle, setRelatedTitle] = useState("");
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [sq, setSq] = useState("");
  const [headerPop, setHeaderPop] = useState<"bell" | "profile" | null>(null);
  const router = useRouter();
  const seasonController = useRef<AbortController | null>(null);
  const sequelController = useRef<AbortController | null>(null);
  function goSearch() { router.push(sq.trim() ? `/?q=${encodeURIComponent(sq.trim())}` : "/"); }
  useEffect(() => {
    try { setHistory(JSON.parse(localStorage.getItem("kuroiru-history") || "[]")); } catch { setHistory([]); }
  }, []);
  async function loadSeason(filterGenre: string) {
    seasonController.current?.abort();
    const controller = new AbortController();
    seasonController.current = controller;
    setLoading(true);
    try {
      const response = await fetch(`/api/season?year=${year}&season=${season}`, { signal: controller.signal });
      const data = await response.json();
      setItems(((data.results || []) as MiniAnime[]).filter(a => a.image && (!filterGenre || (a.genres || []).includes(filterGenre))));
    } catch (error) { if ((error as Error).name !== "AbortError") setItems([]); }
    setLoading(false);
  }
  useEffect(() => { if (tab !== "Anime") return; if (panel === "tags" || panel === "seasons") loadSeason(panel === "tags" ? genre : ""); /* genre/year/season driven */ }, [panel, year, season, genre, tab]);
  useEffect(() => {
    if (panel !== "recs" || tab !== "Anime") return;
    setLoading(true);
    fetch("/api/recommend").then(r => r.json()).then(d => setItems(d.results || [])).catch(() => setItems([])).finally(() => setLoading(false));
  }, [panel, tab]);
  useEffect(() => {
    if (sequelQuery.trim().length < 2) { setSequelResults([]); return; }
    sequelController.current?.abort();
    const controller = new AbortController();
    sequelController.current = controller;
    const timer = setTimeout(() => fetch(`/api/search?q=${encodeURIComponent(sequelQuery)}`, { signal: controller.signal }).then(r => r.json()).then(d => setSequelResults((d.results || []).slice(0, 6))).catch(error => { if ((error as Error).name !== "AbortError") setSequelResults([]); }), 250);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [sequelQuery]);
  function toggle(next: typeof panel) { setPanel(panel === next ? null : next); setRelated([]); }
  return <div className="site-shell">
    <header className="topbar"><Link href="/" className="brand" aria-label="Kuroiru home">Kuroiru</Link>
      <div className="search-area explore-search"><div className="search-box"><input value={sq} onChange={e => setSq(e.target.value)} placeholder="Search anime" aria-label="Search anime" onKeyDown={e => { if (e.key === "Enter") goSearch(); }} /><button title="Search" onClick={goSearch}><Search size={18} /></button></div></div>
      <div className="header-actions"><button aria-label="Notifications" onClick={() => setHeaderPop(headerPop === "bell" ? null : "bell")}><Bell size={20} /></button><button aria-label="Profile" onClick={() => setHeaderPop(headerPop === "profile" ? null : "profile")}><UserRound size={20} /></button></div>
      {headerPop === "bell" && <div className="header-popover">You&apos;re all caught up. New anime appears here as MAL updates.</div>}
      {headerPop === "profile" && <div className="header-popover profile-popover">Your list and history are saved on this browser.</div>}
    </header>
    <main className="explore-main">
      <div className="explore-tabs"><button className={tab === "Anime" ? "selected" : ""} onClick={() => { setTab("Anime"); setPanel(null); }}>Anime</button><button className={tab === "Manga" ? "selected" : ""} onClick={() => { setTab("Manga"); setPanel(null); }}>Manga</button></div>
      <div className="explore-tools">
        <button disabled={tab === "Manga"} className={panel === "tags" ? "tool open" : "tool"} onClick={() => toggle("tags")}><Tags size={14} /> Filter tags</button>
        <button disabled={tab === "Manga"} className={panel === "seasons" ? "tool open" : "tool"} onClick={() => toggle("seasons")}><CalendarDays size={14} /> Seasons</button>
        <button disabled={tab === "Manga"} className={panel === "recs" ? "tool open" : "tool"} onClick={() => toggle("recs")}><FlaskConical size={14} /> Recommendations</button>
        <button disabled={tab === "Manga"} className={panel === "sequel" ? "tool open" : "tool"} onClick={() => toggle("sequel")}><ChevronsUpDown size={14} /> Sequel Locator</button>
      </div>
      {tab === "Manga" && <p className="history-empty-note manga-note">Manga discovery tools are not available yet — these tools query anime catalogs. Switch back to Anime to use them.</p>}
      {tab === "Anime" && panel === "tags" && <div className="explore-panel"><div className="genre-chips">{genres.map(g => <button key={g} className={genre === g ? "chip selected" : "chip"} onClick={() => setGenre(genre === g ? "" : g)}>{g}</button>)}</div></div>}
      {tab === "Anime" && panel === "seasons" && <div className="explore-panel"><select value={year} onChange={e => setYear(Number(e.target.value))} aria-label="Season year">{years.map(y => <option key={y}>{y}</option>)}</select><select value={season} onChange={e => setSeason(e.target.value)} aria-label="Season">{seasons.map(s => <option key={s} value={s}>{s[0].toUpperCase() + s.slice(1)}</option>)}</select></div>}
      {tab === "Anime" && panel === "sequel" && <div className="explore-panel"><input value={sequelQuery} onChange={e => setSequelQuery(e.target.value)} placeholder="Search an anime to locate its sequels" aria-label="Sequel search" />{sequelResults.length > 0 && <div className="sequel-results">{sequelResults.map(a => <button key={a.id} onClick={async () => { setRelatedTitle(a.title); setRelated([]); try { const response = await fetch(`/api/anime?id=${a.id}`); const d = response.ok ? await response.json() : { related: [] }; setRelated(d.related || []); } catch { setRelated([]); } }}>{a.title}</button>)}</div>}{related.length > 0 && <div className="sequel-related"><p>{relatedTitle} — release order:</p>{related.map(r => <Link key={r.id} href={`/anime/${r.id}`}><span>{r.relation}</span>{r.title}</Link>)}</div>}</div>}
      {tab === "Anime" && (panel === "tags" || panel === "seasons" || panel === "recs") && <div className="mini-grid">{loading ? [0,1,2,3,4,5].map(i => <div key={i} className="mini-card skeleton-card" />) : items.slice(0, 12).map(a => <Link key={a.id} href={`/anime/${a.id}`} className="mini-card"><img src={a.image} alt={`${a.title} poster`} loading="lazy" /><span>{a.title}</span></Link>)}</div>}
      <div className="explore-heading history-head"><h2>My History</h2><button title="Clear history" onClick={() => { localStorage.setItem("kuroiru-history", "[]"); setHistory([]); }}><Trash2 size={19} /></button></div>
      <div className="history-list">{history.length ? history.map(h => <Link key={h.id} href={`/anime/${h.id}`} className="history-row"><img src={h.image} alt="" /><span>{h.title}</span><History size={13} /></Link>) : <p className="history-empty-note">Anime you open or stream will appear here.</p>}</div>
    </main>
    <footer className="site-footer"><div><span>Kuroiru.co</span><div><a href="https://myanimelist.net/about.php" target="_blank" rel="noopener noreferrer">About</a><a href="/explore">Explore</a><a href="https://myanimelist.net/about/terms_of_use" target="_blank" rel="noopener noreferrer">Terms</a></div></div><div className="socials"><span>Socials</span><div>🦋 &nbsp;🔴 &nbsp;🟣</div></div></footer>
  </div>;
}
