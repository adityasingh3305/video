"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Search } from "lucide-react";
import type { Anime } from "@/lib/anime";
import { badgeFor, count, footFor, title } from "./home-dashboard";

export function FilterList({ heading, items, mode }: { heading: string; items: Anime[]; mode: "upcoming" | "recent" }) {
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("");
  const [type, setType] = useState("");
  const [minScore, setMinScore] = useState(0);
  const [sort, setSort] = useState(mode === "upcoming" ? "soon" : "new");
  const genres = useMemo(() => {
    const counts = new Map<string, number>();
    items.forEach(a => a.genres.forEach(g => counts.set(g, (counts.get(g) || 0) + 1)));
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 24).map(([g]) => g);
  }, [items]);
  const types = useMemo(() => [...new Set(items.map(a => (a.mediaType || "").toUpperCase()).filter(Boolean))].sort(), [items]);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = items.filter(a =>
      (!q || a.title.toLowerCase().includes(q) || a.altTitles.some(t => t.toLowerCase().includes(q))) &&
      (!genre || a.genres.includes(genre)) &&
      (!type || (a.mediaType || "").toUpperCase() === type) &&
      ((a.score || 0) >= minScore),
    );
    const bySoon = (a: Anime, b: Anime) => (a.startDate || "9999").localeCompare(b.startDate || "9999");
    const byNew = (a: Anime, b: Anime) => (b.startDate || "").localeCompare(a.startDate || "");
    const byScore = (a: Anime, b: Anime) => (b.score || 0) - (a.score || 0);
    const byMembers = (a: Anime, b: Anime) => b.members - a.members;
    return list.sort(sort === "soon" ? bySoon : sort === "new" ? byNew : sort === "score" ? byScore : byMembers);
  }, [items, query, genre, type, minScore, sort]);
  return <div className="site-shell">
    <header className="topbar"><Link href="/" className="brand" aria-label="Kuroiru home">Kuroiru</Link>
      <div className="search-area explore-search"><div className="search-box"><input value={query} onChange={e => setQuery(e.target.value)} placeholder={`Filter ${heading.toLowerCase()} by title`} aria-label="Filter by title" /><span className="search-count">{filtered.length}</span></div></div>
      <div className="header-actions"><Link href="/" aria-label="Back to home" className="back-link"><ArrowLeft size={22} /></Link></div>
    </header>
    <main className="filter-page">
      <div className="filter-head"><h1>{heading} <span>{filtered.length}</span></h1><p>From MAL&apos;s {mode === "upcoming" ? "current and next season" : "current season"} catalogs, rankings included.</p></div>
      <div className="filter-bar">
        <select value={genre} onChange={e => setGenre(e.target.value)} aria-label="Filter by genre"><option value="">All genres</option>{genres.map(g => <option key={g}>{g}</option>)}</select>
        <select value={type} onChange={e => setType(e.target.value)} aria-label="Filter by type"><option value="">All types</option>{types.map(t => <option key={t}>{t}</option>)}</select>
        <select value={minScore} onChange={e => setMinScore(Number(e.target.value))} aria-label="Minimum score"><option value={0}>Any score</option><option value={6}>6+</option><option value={7}>7+</option><option value={8}>8+</option></select>
        <select value={sort} onChange={e => setSort(e.target.value)} aria-label="Sort"><option value={mode === "upcoming" ? "soon" : "new"}>{mode === "upcoming" ? "Soonest first" : "Newest first"}</option><option value="score">Highest score</option><option value="members">Most members</option></select>
      </div>
      {filtered.length ? <div className="anime-grid page-grid">{filtered.map((a, i) => <Link key={`${a.id}-${i}`} href={`/anime/${a.id}`} className="anime-card" aria-label={`View ${title(a)}`}>
        <div className="poster-frame">{a.image ? <img src={a.image} alt={`${title(a)} poster`} loading="lazy" /> : <div className="poster-empty" />}<span className="poster-top">{a.score ? a.score.toFixed(2) : "?"} ♙ {count(a.members)}</span><span className="poster-count">{badgeFor(mode, a)}</span></div>
        <div className="card-caption"><span className="card-title">{title(a)}</span><span className="card-foot">{footFor(mode, a)}</span></div>
      </Link>)}</div> : <div className="filter-empty"><Search size={22} /><p>No anime match these filters.</p><button onClick={() => { setQuery(""); setGenre(""); setType(""); setMinScore(0); }}>Clear filters</button></div>}
    </main>
    <footer className="site-footer"><div><span>Kuroiru.co</span><div><a href="/about">About</a><a href="/explore">Explore</a><a href="/terms">Terms</a></div></div><div className="socials"><span>Socials</span><div className="social-links"><a href="https://myanimelist.net" target="_blank" rel="noopener noreferrer" title="MyAnimeList">MAL</a><a href="https://anilist.co" target="_blank" rel="noopener noreferrer" title="AniList">AniList</a><a href="https://ani.zip" target="_blank" rel="noopener noreferrer" title="AniZip">AniZip</a></div></div></footer>
  </div>;
}
